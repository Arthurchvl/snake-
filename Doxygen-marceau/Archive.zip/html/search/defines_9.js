var searchData=
[
  ['taille_5fmax_5fserpent_0',['TAILLE_MAX_SERPENT',['../snake_8c.html#a717e1b831187df8c37fbdd08fa81cae0',1,'snake.c']]],
  ['taille_5fserpent_1',['TAILLE_SERPENT',['../snake_8c.html#a1fc4c65b893fe1bc5fc4afa72e3c1a6d',1,'snake.c']]],
  ['true_2',['TRUE',['../snake_8c.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'snake.c']]]
];

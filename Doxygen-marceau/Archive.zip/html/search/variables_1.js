var searchData=
[
  ['nombres_5fpaves_0',['NOMBRES_PAVES',['../snake_8c.html#afae39120a367901eb27e47a2e7c829f2',1,'snake.c']]]
];

var indexSectionsWithContent =
{
  0: "abcdefghiklmnopstv",
  1: "s",
  2: "adegikmp",
  3: "cnopstv",
  4: "p",
  5: "abcdfghlpt"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Variables",
  4: "Définitions de type",
  5: "Macros"
};


var searchData=
[
  ['coord_5fdepart_5fx_5fserpent_0',['COORD_DEPART_X_SERPENT',['../snake_8c.html#aa6bf363f84d94618f16561ae092f2db0',1,'snake.c']]],
  ['coord_5fdepart_5fy_5fserpent_1',['COORD_DEPART_Y_SERPENT',['../snake_8c.html#afe3a372f3d3ca368c18235dd3c4fce71',1,'snake.c']]],
  ['corps_2',['CORPS',['../snake_8c.html#adb033a6add57b80ca03364c8b5665528',1,'snake.c']]],
  ['cote_5fbordure_3',['COTE_BORDURE',['../snake_8c.html#a9c1de00a050e306dbe6252bbb5771c4e',1,'snake.c']]]
];

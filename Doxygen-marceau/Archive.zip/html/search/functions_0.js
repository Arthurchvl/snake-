var searchData=
[
  ['afficher_0',['afficher',['../snake_8c.html#acba1573a94ed488d9e14fdaaf32d9bc4',1,'snake.c']]],
  ['ajouterpomme_1',['ajouterPomme',['../snake_8c.html#a2ae6e8d345803177af75e878e2b30d68',1,'snake.c']]]
];

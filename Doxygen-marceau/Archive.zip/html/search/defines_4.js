var searchData=
[
  ['false_0',['FALSE',['../snake_8c.html#aa93f0eb578d23995850d61f7d61c55c1',1,'snake.c']]]
];

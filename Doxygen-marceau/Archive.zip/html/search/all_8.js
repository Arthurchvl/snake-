var searchData=
[
  ['initplateau_0',['initPlateau',['../snake_8c.html#a11dd4ed7990102abfc10772f2ddb4cc3',1,'snake.c']]]
];

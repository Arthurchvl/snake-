var searchData=
[
  ['vide_0',['VIDE',['../snake_8c.html#a65e70a095fdc823063b2d115d50a391f',1,'snake.c']]],
  ['vitesse_5factuelle_1',['vitesse_actuelle',['../snake_8c.html#a2971f17e034677862839f927422f40bc',1,'snake.c']]],
  ['vitesse_5fjeu_2',['VITESSE_JEU',['../snake_8c.html#a9ae8050b81051735a66543522833525f',1,'snake.c']]]
];

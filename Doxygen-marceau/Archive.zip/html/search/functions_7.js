var searchData=
[
  ['placerpaves_0',['placerPaves',['../snake_8c.html#a657b5f67361457093a363b2e5e5e8ae5',1,'snake.c']]],
  ['progresser_1',['progresser',['../snake_8c.html#a131ab0610992317355b2e56d74e7cb35',1,'snake.c']]]
];

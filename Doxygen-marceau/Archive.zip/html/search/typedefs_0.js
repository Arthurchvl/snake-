var searchData=
[
  ['plateauglobale_0',['plateauGlobale',['../snake_8c.html#a8671f567faa50fca0b78b6aab269c478',1,'snake.c']]]
];

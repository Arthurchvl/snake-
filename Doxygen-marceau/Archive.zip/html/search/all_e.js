var searchData=
[
  ['placerpaves_0',['placerPaves',['../snake_8c.html#a657b5f67361457093a363b2e5e5e8ae5',1,'snake.c']]],
  ['plateauglobale_1',['plateauGlobale',['../snake_8c.html#a8671f567faa50fca0b78b6aab269c478',1,'snake.c']]],
  ['plateaujeu_2',['plateauJeu',['../snake_8c.html#a4cd8447beff3fcd8300047b85f8a7702',1,'snake.c']]],
  ['pomme_3',['POMME',['../snake_8c.html#a6eb969c6062d9b1ea982bca54c1f1732',1,'snake.c']]],
  ['progresser_4',['progresser',['../snake_8c.html#a131ab0610992317355b2e56d74e7cb35',1,'snake.c']]]
];
